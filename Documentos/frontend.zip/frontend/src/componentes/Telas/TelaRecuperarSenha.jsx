import RecuperarSenha from "./Formularios/RecuperarSenha";

export default function TelaRecuperarSenha(){
    return(
        <RecuperarSenha/>
    );
}